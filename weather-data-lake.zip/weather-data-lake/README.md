The Project is about fetching weather updates in real time and using AWS resources to deploy them.

Weather Data Pipeline — Lambda → S3 → Glue Job (JSON to CSV). Can be fed to Quicksight for analytics.

The CF Template contains complete flow of Lambda fetching weather data from Open API and ingesting it to S3. Glue job(2 options- Glue Studio and Spark ETL) triggering to convert S3 contents to destination S3 bucket in csv format. The Output S3 contents in csv can be ingesting manually into Quicksight for analytics.

Not contained in CF template:

Lambda Function and its dependencies.
The complete Lambda function package resides in S3 bucket.
The S3 bucket and key are mentioned as parameters in CF template.
For the first time, Glue job needs to be created manually for csv creation. This stores script for the conversion in S3. Once script is stored in S3, the S3 buckets- raw and processed can be deleted. As these will be created in CF.

* Glue job not getting triggered because of Python Version.