import json
import os
import requests
import boto3


s3client=boto3.client('s3')

API_KEY = os.getenv('OPENWEATHER_API_KEY')


CITIES = ['New York', 'London', 'Tokyo', 'Sydney']

def fetch_weather_data(city):
    base_url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {
        'q': city,
        'appid': API_KEY,
        'units': 'metric'
    }
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching data for {city}: {response.status_code} - {response.text}")
        return None

def lambda_handler(event, context):
    if not API_KEY:
        return {'statusCode': 500, 'body': 'Missing API key'}

    results = []
    for city in CITIES:
        data = fetch_weather_data(city)
        if data:
            results.append({
                'city': city,
                'temperature': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'weather': data['weather'][0]['description']
            })

    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }
