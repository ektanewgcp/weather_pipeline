import json
import os
import requests
import boto3
from datetime import datetime

API_KEY = os.getenv('OPENWEATHER_API_KEY')
S3_BUCKET = os.getenv('S3_BUCKET')
s3_client = boto3.client('s3')

CITIES = ['New York', 'London', 'Tokyo', 'Sydney']

def fetch_weather_data(city):
    base_url = 'https://api.openweathermap.org/data/2.5/weather'
    params = {'q': city, 'appid': API_KEY, 'units': 'metric'}
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching data for {city}: {response.status_code} - {response.text}")
        return None

def upload_to_s3(data, bucket):
    timestamp = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    key = f"weather_data_{timestamp}.json"
    s3_client.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data, indent=2),
        ContentType='application/json'
    )
    print(f"Uploaded weather data to s3://{bucket}/{key}")

def lambda_handler(event, context):
    if not API_KEY:
        print("Missing API key")
        return {'statusCode': 500, 'body': 'Missing API key'}

    results = []
    for city in CITIES:
        data = fetch_weather_data(city)
        if data:
            results.append({
                'city': city,
                'temperature': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'weather': data['weather'][0]['description']
            })

    if results:
        upload_to_s3(results, S3_BUCKET)
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Data uploaded to S3', 'record_count': len(results)})
        }
    else:
        return {
            'statusCode': 500,
            'body': 'Failed to fetch weather data.'
        }
